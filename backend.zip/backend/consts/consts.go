package consts

const AccessKey = "UbG9NVTSj7i4kJ_BAUWcaQi6CrVPgOPRh5eWrDdA"
const SecretKey = "UxuMXKJ4Sx7gAPmBht4mzEKWaK9D9_MNGXQpy8lo"
