package responses

// LoginResponse 登录返回响应结构体
type LoginResponse struct {
	// 状态码，0-成功，其他值-失败
	StatusCode int `json:"status_code"`
	// 返回状态描述
	StatusMsg string `json:"status_msg"`
	// 用户鉴权token
	Token string `json:"token"`
	// 用户id
	UserID uint `json:"user_id"`
}

// RegisterResponse 注册返回响应结构体
type RegisterResponse struct {
	// 状态码，0-成功，其他值-失败
	StatusCode int `json:"status_code"`
	// 返回状态描述
	StatusMsg string `json:"status_msg"`
	// 用户鉴权token
	Token string `json:"token"`
	// 用户id
	UserID uint `json:"user_id"`
}

// UserResponse 用户信息返回响应结构体
type UserResponse struct {
	// 状态码，0-成功，其他值-失败
	StatusCode int `json:"status_code"`
	// 返回状态描述
	StatusMsg string `json:"status_msg"`
	// 用户信息
	User User `json:"user"`
}

// User 用户信息结构体
type User struct {
	// 用户id
	ID uint `json:"id"`
	// 用户名称
	Name string `json:"name"`
	// 用户头像
	Avatar string `json:"avatar"`
	// 用户个人页顶部大图
	BackgroundImage string `json:"background_image"`
	// 个人简介
	Signature string `json:"signature"`

	// 关注总数
	FollowCount int `json:"follow_count"`
	// 粉丝总数
	FollowerCount int `json:"follower_count"`
	// 获赞数量
	TotalFavorited int `json:"total_favorited"`
	// 作品数
	WorkCount int `json:"work_count"`
	// 喜欢数
	FavoriteCount int `json:"favorite_count"`

	// true-已关注，false-未关注
	IsFollowed bool `json:"is_follow"`
}
